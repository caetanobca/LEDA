package adt.hashtable.open;

public interface Storable {

}
